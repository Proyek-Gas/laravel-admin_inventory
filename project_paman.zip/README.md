# laravel-admin_inventory
Admin buat penjualan dan pembelian barang
